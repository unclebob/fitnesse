// Copyright (C) 2003,2004,2005 by Object Mentor, Inc. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package eg.employeePayroll;

import java.util.Date;

public class PayCheck
{
  public int id;
  public double amount;
  public int number;
  public String name;
  public Date date;
}
