package fitnesse.slim;

public class SlimVersion {
  public static String VERSION = "V0.0";
}
