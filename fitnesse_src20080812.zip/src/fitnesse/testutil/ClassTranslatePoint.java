package fitnesse.testutil;

import fit.TypeAdapter;

import java.awt.*;

public class ClassTranslatePoint extends TranslatePoint
{
	static
	{
		TypeAdapter.registerParseDelegate(Point.class, ClassDelegatePointParser.class);
	}
}
